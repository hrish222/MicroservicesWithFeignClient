package com.hash.credit_service.Client;



import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.util.Date;

public class AuditListener {

    @PrePersist
    public void setCreatedAtAndCreatedBy(Object entity) {
        if (entity instanceof Auditable) {
            Auditable auditable = (Auditable) entity;
            Date now = new Date();
            auditable.setCreatedAt(now);
            auditable.setUpdatedAt(now);
            // Set createdBy and updatedBy from the context, e.g., the current user
            auditable.setCreatedBy(getCurrentUserId());
            auditable.setUpdatedBy(getCurrentUserId());
        }
    }

    @PreUpdate
    public void setUpdatedAtAndUpdatedBy(Object entity) {
        if (entity instanceof Auditable) {
            Auditable auditable = (Auditable) entity;
            auditable.setUpdatedAt(new Date());
            // Set updatedBy from the context, e.g., the current user
            auditable.setUpdatedBy(getCurrentUserId());
        }
    }

    private Integer getCurrentUserId() {
        // Implement logic to fetch the current user's ID
        // This might involve fetching from a security context or session
        return 1; // Example user ID
    }
}
