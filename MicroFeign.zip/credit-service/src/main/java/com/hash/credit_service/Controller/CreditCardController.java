package com.hash.credit_service.Controller;


import com.hash.credit_service.Model.CreditCard;
import com.hash.credit_service.Service.CreditCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/credit-cards")
public class CreditCardController {

    @Autowired
    private CreditCardService creditCardService;

    @PostMapping("/savecard")
    public CreditCard createCreditCard(@RequestBody CreditCard creditCard) {
        return creditCardService.createCreditCard(creditCard);
    }

    @GetMapping("/{CreditCId}")
    public CreditCard getCredtCardById(@PathVariable String CreditCId) {
        return creditCardService.getCreditCardById(CreditCId );
    }

    @GetMapping("/user/{userId}")
    public List<CreditCard> getCreditCardsByUserId(@PathVariable String userId) {
        return creditCardService.getCreditCardsByUserId(userId);
    }

    @PutMapping("/{CreditCId}")
    public CreditCard updateCreditCard(@PathVariable String CreditCId, @RequestBody CreditCard creditCard) {
        return creditCardService.updateCreditCard(CreditCId, creditCard);
    }

    @DeleteMapping("/{CreditCId}")
    public void deleteCreditCard(@PathVariable String CreditCId) {
        creditCardService.deleteCreditCard(CreditCId);
    }


    @GetMapping("/transaction/{transId}")
    public ResponseEntity<List<CreditCard>> getTransactionByTransId(@PathVariable String transId) {
        return ResponseEntity.ok(creditCardService.getTransactionByTransId(transId));
    }
}
