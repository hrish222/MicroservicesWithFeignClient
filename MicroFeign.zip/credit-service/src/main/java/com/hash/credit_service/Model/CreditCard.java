package com.hash.credit_service.Model;

import com.hash.credit_service.Client.AuditListener;
import com.hash.credit_service.Client.Auditable;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="CreditCard")
@EntityListeners(AuditListener.class)
public class CreditCard implements Auditable {
    @Id
    @Column(name="CreditCID" ,nullable = false,length=50)
    private String CreditCId;
    @Column(name="CardNo" ,nullable = false,length=50)
    private String cardNumber;
    @Column(name="CardHolder" ,nullable = false,length=50)
    private String cardHolderName;
    @Column(name="IssueDate" ,nullable = false,length=50)
    private String issueDate;
    @Column(name="ExpiryDate" ,nullable = false,length=50)
    private String expiryDate;
    @NotNull
    @Column(name="UserID",nullable = false,length=50)
    private String userId;
    @Column(name="TransId",nullable = false,length=50)
    private  String transId;
    @Transient
    private Transaction transaction;
    @Column
    private Integer createdBy;
    @Column
    private Integer updatedBy;
    @Column
    private Date createdAt;
    @Column
    private Date updatedAt;
    @Transient
    private List<User> Users=new ArrayList<>();
    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCreditCId() {
        return CreditCId;
    }

    public void setCreditCId(String creditCId) {
        CreditCId = creditCId;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public Integer getCreatedBy() {
        return createdBy;
    }

    @Override
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public Integer getUpdatedBy() {
        return updatedBy;
    }

    @Override
    public void setUpdatedBy(Integer updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public Date getCreatedAt() {
        return createdAt;
    }

    @Override
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public Date getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<User> getUsers() {
        return Users;
    }

    public void setUsers(List<User> users) {
        Users = users;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }
}
