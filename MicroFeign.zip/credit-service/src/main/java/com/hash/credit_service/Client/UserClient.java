package com.hash.credit_service.Client;

import com.hash.credit_service.Model.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
@Service
@FeignClient(name = "UserApplication")
public interface UserClient {

    @GetMapping("/users/getdata/{userId}")
    User getUserById(@PathVariable("userId") String userId);
}
