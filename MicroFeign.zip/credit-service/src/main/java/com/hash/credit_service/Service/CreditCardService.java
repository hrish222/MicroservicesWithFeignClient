package com.hash.credit_service.Service;

//import com.hash.credit_service.Client.UserClient;
import com.hash.credit_service.Client.UserClient;
import com.hash.credit_service.Exception.CreditCardNotFoundException;
import com.hash.credit_service.Exception.ResourceNotFoundException;
import com.hash.credit_service.Model.CreditCard;
import com.hash.credit_service.Model.User;
import com.hash.credit_service.Repository.CreditCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CreditCardService {

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Autowired
    private UserClient userClient;

    public CreditCard createCreditCard(CreditCard creditCard) {
        if (creditCard.getCreditCId() == null || creditCard.getCreditCId().isEmpty()) {
            // You can generate an ID here or set it from the input
            creditCard.setCreditCId(UUID.randomUUID().toString());
        }
        return creditCardRepository.save(creditCard);
    }

    public CreditCard getCreditCardById(String CreditCId) {
        return creditCardRepository.findById(CreditCId)
                .orElseThrow(() -> new CreditCardNotFoundException("Credit card not found with id: " + CreditCId));
    }


public List<CreditCard> getCreditCardsByUserId(String userId) {

    return  creditCardRepository.findByUserId(userId);

}

//    public List<CreditCard> getCreditCardsByUserId(String userId) {
//        // Fetch user details using Feign Client
//        User user = userClient.getUserById(userId);
//
//        // Fetch credit cards by userId from the repository
//        Optional<CreditCard> creditCardList = creditCardRepository.findById(userId);
//
//        if (creditCardList.isEmpty()) {
//            throw new ResourceNotFoundException("No credit cards found for user with id " + userId);
//        }
//
//        return creditCardList;
//    }

    public CreditCard updateCreditCard(String CreditCId, CreditCard creditCard) {
        CreditCard existingCreditCard = getCreditCardById(CreditCId);
        existingCreditCard.setCardNumber(creditCard.getCardNumber());
        existingCreditCard.setCardHolderName(creditCard.getCardHolderName());
        existingCreditCard.setExpiryDate(creditCard.getExpiryDate());
        existingCreditCard.setUserId(creditCard.getUserId());
        return creditCardRepository.save(existingCreditCard);
    }

    public void deleteCreditCard(String CreditCId ) {
        CreditCard creditCard = getCreditCardById(CreditCId);
        creditCardRepository.delete(creditCard);
    }




    public List<CreditCard> getTransactionByTransId(String transId) {
        return  creditCardRepository.getTransactionByTransId(transId);
    }
}
