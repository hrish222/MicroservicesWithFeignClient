package com.hash.credit_service.Repository;


import com.hash.credit_service.Model.CreditCard;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CreditCardRepository extends JpaRepository<CreditCard, String> {
    List<CreditCard> findByUserId(String userId);

    List<CreditCard> getTransactionByTransId(String transId);
}
