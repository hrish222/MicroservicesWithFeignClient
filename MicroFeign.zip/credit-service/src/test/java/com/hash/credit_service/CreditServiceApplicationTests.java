package com.hash.credit_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
