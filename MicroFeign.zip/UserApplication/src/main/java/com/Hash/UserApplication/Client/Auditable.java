package com.Hash.UserApplication.Client;

import java.util.Date;

public interface Auditable {
    void setCreatedAt(Date createdAt);
    void setUpdatedAt(Date updatedAt);
    void setCreatedBy(Integer createdBy);
    void setUpdatedBy(Integer updatedBy);

    Date getCreatedAt();
    Date getUpdatedAt();
    Integer getCreatedBy();
    Integer getUpdatedBy();
}
