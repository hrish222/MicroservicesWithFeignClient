package com.Hash.UserApplication.Client;


import com.Hash.UserApplication.Model.CreditCard;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Service
@FeignClient(name = "credit-service")
public interface CreditCardClient {

    @GetMapping("/credit-cards/user/{userId}")
    CreditCard[] getCreditCardsByUserId(@PathVariable("userId") String userId);

    @PostMapping("/credit-cards/savecard")
    public ResponseEntity<CreditCard> createRating(CreditCard values);


    //PUT
    @PutMapping("/credit-cards/{CreditCId}")
    public ResponseEntity<CreditCard> updateRating(@PathVariable("CreditCId") String ratingId, CreditCard creditCard);


    @DeleteMapping("/credit-cards/{CreditCId}")
    public void deleteRating(@PathVariable String CreditCId);
}

