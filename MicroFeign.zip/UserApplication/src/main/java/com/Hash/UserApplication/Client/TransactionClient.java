package com.Hash.UserApplication.Client;

import com.Hash.UserApplication.Model.Transaction;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
@Service

@FeignClient(name = "transaction-service")
public interface TransactionClient {



        @GetMapping("/transactions/{transId}")
        Transaction getTransactionByTransId(@PathVariable("transId") String transId);



}
