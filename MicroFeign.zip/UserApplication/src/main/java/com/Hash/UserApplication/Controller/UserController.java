package com.Hash.UserApplication.Controller;

import com.Hash.UserApplication.Client.CreditCardClient;
import com.Hash.UserApplication.Model.CreditCard;
import com.Hash.UserApplication.Model.User;
import com.Hash.UserApplication.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;



   @GetMapping("/test")
   public String getData(){
       return "Hi route is correct";
   }

    @PostMapping("/save")
    public ResponseEntity<User> createUserProfile( @RequestBody User user) {
        User createdUserProfile = userService.saveUser(user);
        return ResponseEntity.ok(createdUserProfile);
    }

    @GetMapping("/getdata/{userId}")
    public ResponseEntity<User> getuserById(@PathVariable String userId) {
        User user = userService.getUserById(userId);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/username/{username}")
    public ResponseEntity<User> getUserbyUsername(@PathVariable String username) {
        User user = userService.getUserByUsername(username);
        return ResponseEntity.ok(user);
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<User> updateUserProfile(@PathVariable String userId,  @RequestBody User userDetails) {
        User updatedUserData = userService.updateUserProfile(userId, userDetails);
        return ResponseEntity.ok(updatedUserData);
    }

    @DeleteMapping("/delate/{userId}")
    public ResponseEntity<String> deleteUserProfile(@PathVariable String userId) {
        userService.deleteUserProfile(userId);
        return ResponseEntity.ok("UserProfile deleted successfully");
    }
    @PostMapping("/{userId}/add-credit-card")
    public CreditCard addCreditCard(@PathVariable String userId, @RequestBody CreditCard creditCard) {
        creditCard.setUserId(userId); // Ensure the card is linked to the correct user
        return userService.addCreditCard(creditCard);
    }

//    public List<Object> getCreditCardsByUserId(@PathVariable Integer userId) {
//        return creditCardClient.getCreditCardsByUserId(userId);
//    }
//    @GetMapping("/{userId}")
//    public List<Object> getCreditCardsByUserId(@PathVariable Integer userId) {
//        return (List<Object>) userService.getUserWithCreditCards(userId);
//    }
}
