package com.Hash.UserApplication.Service;


import com.Hash.UserApplication.Client.CreditCardClient;
import com.Hash.UserApplication.Client.TransactionClient;
import com.Hash.UserApplication.Exception.ResourceNotFoundException;
import com.Hash.UserApplication.Model.CreditCard;
import com.Hash.UserApplication.Model.Transaction;
import com.Hash.UserApplication.Model.User;
import com.Hash.UserApplication.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private CreditCardClient creditCardClient;
    @Autowired
    TransactionClient transactionClient;


    private final RestTemplate restTemplate;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(RestTemplate restTemplate, PasswordEncoder passwordEncoder) {
        this.restTemplate = restTemplate;
        this.passwordEncoder = passwordEncoder;
    }


        public User saveUser(User user) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));

            User savedUser = userRepository.save(user);

            return savedUser;
        }

        public User getUserById(String userId) {
            User user= userRepository.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("UserProfile not found with id " + userId));
                //using resttemplate->below line
//            CreditCard[] cardsOfUser = restTemplate.getForObject("http://localhost:8085/credit-service/credit-cards/user/" + user.getUserId(), CreditCard[].class);
            CreditCard[] cardsOfUser = creditCardClient.getCreditCardsByUserId(user.getUserId());
            List<CreditCard> creditCardList = Arrays.asList(cardsOfUser);

            List<CreditCard> updatedCreditCards = creditCardList.stream().map(creditCard -> {
                Transaction transaction = transactionClient.getTransactionByTransId(creditCard.getTransId());
                creditCard.setTransaction(transaction);
                return creditCard;
            }).collect(Collectors.toList());

            user.setCredCard(updatedCreditCards);
            return user;
        }

    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User updateUserProfile(String userId, User userDetaills) {
        User userProfile = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("UserProfile not found with id " + userId));
        userProfile.setUsername(userDetaills.getUsername());
        userProfile.setPassword(passwordEncoder.encode(userDetaills.getPassword()));
        userProfile.setRole(userDetaills.getRole());
        userProfile.setAddress(userDetaills.getAddress());
        userProfile.setPhoneNumber(userDetaills.getPhoneNumber());
        userProfile.setAccountNumber(userDetaills.getAccountNumber());
        userProfile.setEmail(userDetaills.getEmail());
        userProfile.setGender(userDetaills.getGender());
        return userRepository.save(userProfile);
    }

    public void deleteUserProfile(String userId) {
        User userProfile = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("UserProfile not found with id " + userId));
        userRepository.delete(userProfile);
    }

    public CreditCard addCreditCard(CreditCard creditCard) {
        ResponseEntity<CreditCard> response = creditCardClient.createRating(creditCard);
        return response.getBody();
    }


}


