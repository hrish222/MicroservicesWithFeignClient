package com.Hash.UserApplication.Model;

import com.Hash.UserApplication.Client.AuditListener;
import com.Hash.UserApplication.Client.Auditable;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "users_details")
@EntityListeners(AuditListener.class)
public class User implements Auditable {
    @Id
    @Column(name="ID",nullable = false,length=50)
    private String userId;
    @Column(name="User" ,nullable = false,length=50)
    private String username;
    @Column(name="Gender" ,nullable = false,length=50)
    private String gender;
    @Column(name="Address" ,nullable = false,length=50)
    private String address;
    @Column(name="AccountNumber" ,nullable = false,length=50)
    private String accountNumber;
    @Column(name="Email" ,nullable = false,unique = true,length=50)
    private String email;
    @Column(name="Password" ,nullable = false,length=225)
    private String password;
    @Column(name="Role" ,nullable = false,length=50)
    private String role;
    @Column(name="PhoneNumber" ,nullable = false,length=50)
    private String phoneNumber;

    @Column
    private Integer createdBy;
    @Column
    private Integer updatedBy;
    @Column
    private Date createdAt;
    @Column
    private Date updatedAt;

    @Transient
    private List<CreditCard> CredCard=new ArrayList<>();

    public User() {
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<CreditCard> getCredCard() {
        return CredCard;
    }

    public void setCredCard(List<CreditCard> credCard) {
        CredCard = credCard;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }



    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }



    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Integer updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}
