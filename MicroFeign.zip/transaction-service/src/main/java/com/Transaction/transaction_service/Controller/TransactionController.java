package com.Transaction.transaction_service.Controller;

import com.Transaction.transaction_service.Model.Transaction;
import com.Transaction.transaction_service.Service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/create")
    public ResponseEntity<Transaction> createTransaction(@RequestBody Transaction transaction) {
        Transaction createdTransaction = transactionService.createTransaction(transaction);
        return ResponseEntity.ok(createdTransaction);
    }

//    @GetMapping("/user/{userId}")
//    public ResponseEntity<List<Transaction>> getTransactionsByUserId(@PathVariable String userId) {
//        List<Transaction> transactions = transactionService.getTransactionsByUserId(userId);
//        return ResponseEntity.ok(transactions);
//    }
@GetMapping("/{transId}")
public Transaction getTransactionByTransId(@PathVariable String transId) {
    return transactionService.getTransactionByTransId(Long.valueOf(transId));
}
    @GetMapping("/credit-card/{creditCardId}")
    public ResponseEntity<List<Transaction>> getTransactionsByCreditCardId(@PathVariable String creditCardId) {
        List<Transaction> transactions = transactionService.getTransactionsByCreditCardId(creditCardId);
        return ResponseEntity.ok(transactions);
    }

    @PutMapping("/update-status/{transId}")
    public ResponseEntity<Void> updateTransactionStatus(@PathVariable String transId, @RequestBody String status) {
        transactionService.updateTransactionStatus(String.valueOf(Long.valueOf(transId)), status);
        return ResponseEntity.ok().build();
    }
}
