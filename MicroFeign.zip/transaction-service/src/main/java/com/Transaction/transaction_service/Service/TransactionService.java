package com.Transaction.transaction_service.Service;

import com.Transaction.transaction_service.Exception.ResourceNotFoundException;
import com.Transaction.transaction_service.Model.Transaction;
import com.Transaction.transaction_service.Repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Transactional
    public Transaction createTransaction(Transaction transaction) {
        transaction.setStatus("PENDING");
//        transaction.setTimestamp(new Date());
        return transactionRepository.save(transaction);
    }
    public Transaction getTransactionByTransId(Long transId) {
        return transactionRepository.findById(String.valueOf(transId))
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id " + transId));
    }
//    public List<Transaction> getTransactionsByUserId(String userId) {
//        return transactionRepository.findByUserId(userId);
//    }

    public List<Transaction> getTransactionsByCreditCardId(String creditCardId) {
        return transactionRepository.findByCreditCardId(creditCardId);
    }

    public Optional<Transaction> getTransactionById(String transId) {
        return transactionRepository.findById(transId);
    }

    @Transactional
    public void updateTransactionStatus(String transId, String status) {
        Transaction transaction = transactionRepository.findById(transId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));
        transaction.setStatus(status);
        transactionRepository.save(transaction);
    }
}
